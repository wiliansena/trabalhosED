class ListaEstatica:
    lista_nome = []
    lista_codigo = []
    lista_cargo = []
    listagem =[]
    qtde = 0
    tamanho = len(listagem)

    def __init__(self):
        self.lista_nome = []
        self.lista_codigo = []
        self.lista_cargo =  []
        self.listagem = []
        self.qtde = len(self.lista_codigo)
        self.tamanho = 3

    def inserir(self, nome, codigo, cargo):
        self.lista_codigo.append(codigo)
        self.lista_nome.append(nome)
        self.lista_cargo.append(cargo)
        self.qtde += 1
        print(self.listagem.index(self.lista_codigo))

    def remover(self, remove_funcionario):
        try:
            objFunc = self.lista_codigo.index(remove_funcionario)
            if remove_funcionario == self.lista_codigo[objFunc]:
                 lista_remove = self.listagem[objFunc]
                 self.listagem.remove(lista_remove)
                 self.qtde-=1
                 print(self.listagem)
        except:
            print("ERRO! Não foi possível remover o funcionário!")

    def mostrar(self):
        if self.qtde == 0:
            print("LISTA VAZIA!")
        else:
            self.listagem = list(zip(self.lista_nome, self.lista_codigo, self.lista_cargo))
            self.listagem.sort()
            print(self.listagem)

    def buscar(self, buscar_funcionario):

          objFunci = self.lista_codigo.index(buscar_funcionario)
          print(objFunci)
          if buscar_funcionario == self.lista_codigo[objFunci]:
                print("FUNCIONARIO:  \n", self.listagem[objFunci])

          else:
                print("FUNCIONARIO NÃO ENCONTRADO!")


    def limpar(self):
        self.lista_codigo.clear()
        self.listagem.clear()
        self.lista_nome.clear()
        self.lista_cargo.clear()
        self.qtde = 0






