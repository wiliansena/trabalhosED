class No:
    def _init_(self,dado):
        self.dado=dado
        self.proximo=None

    def getDado(self):
        return self.dado
            def setDado(self, dado):
        self.dado = dado

    def getProximo(self):
        return self.proximo

    def setProximo(self, novoNo):
        self.proximo = novoNo


class List:
    def _init_(self):
        self.antNo=None
        self.proxNo=None
    def __str__(self)
        if self.isEmpty():
            return "A lista está vazia!"
            iNo = self.antNo
        String = "A lista é: "
        while iNo is not None:
            String += str(iNo.getDado()) + " "
            iNo = iNo.getProximo()
            return String

    def Inserir(self, valor):
            novoNo = No(valor)
        if self.isEmpty(): #inserir novo valor quando a lista for vazia
                self.antNo = self.proxNo = novoNo
            else #inserir quando a lista não estiver vazia
                novoNo = setProximo(self.antNo)
                self.antNo = novoNo

    def InserirNoFinal(self, valor):
            novoNo = No(valor)
        if self.isEmpty(): #inserir novo valor quando a lista for vazia
           self.antNo = self.proxNo = novoNo
            else #inserir quando a lista não estiver vazia
                self.proxNo.setProximo(novoNo)
                self.proxNo = novoNo

    def Remover(self):
        if self.isEmpty():
            raise print( "Remossão de uma lista vazia!")
            antNoValor = self.antNo.getDado()
        if self.antNo is self.proxNo:
                self.antNo = self.proxNo = None
            else:
                self.antNo = self.antNo.getProximo()
                return antNoValor

            def RemoverNoFinal(self):
                if self.isEmpty():
                    raise print("Remoção de Lista Vazia")
                    proxNoValor = self.proxNo.getDado()
                    if self.antNo is self.proxNo:
                        self.antNo = self.proxNo = None
                        else:
                            iNo = self.antNo
                            while iNo.getProximo() is not self.proxNo:
                                iNo = iNo.getProximo()
                                iNo.setProximo(None)
                                self.proxNo = iNo
                                return proxNoValor


            def Vazia():
                return self.antNo is None