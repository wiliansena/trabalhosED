class Funcionario:
    __codigo = ""
    __nome = ""
    __cargo = ""

    def get_codigo(self):
        return self.__codigo

    def set_codigo(self,codigo):
        self.__codigo = codigo

    def get_nome(self):
        return self.__nome

    def set_nome(self, nome):
        self.__nome = nome

    def get_cargo(self):
        return self.__cargo

    def set_cargo(self, cargo):
        self.__cargo = cargo

    def mostrar_funcionario(self):
        print(self.__codigo, " - ", self.__nome, " - ", self.__cargo)