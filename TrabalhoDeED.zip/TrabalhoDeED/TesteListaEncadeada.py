import sys
from ListaEncadeada import List
from ListaEncadeada import No
from Main import Main

def Main():
	print("Escolha uma Opção:\n", \
		"1 INSERIR no inicio da lista\n",\
		"2 INSERIR no final da lista\n",\
		"3 DELETAR no começo da lista\n",\
		"4 DELETAR no final da lista\n",\
		"5 Sair\n")

	listObject = list()
	Main()
	resposta = input("? ")
	while resposta != "5":
		if resposta == "1":
		listObject.Inserir(input("Digite o valor: "))
		print(listObject)
			elif resposta == "2":
		listObject.InserirNoFinal(input("Digite o valor"))
		print(listObject)
			elif resposta == "3":
				try:
				valor = listObject.Remover()
				except :
				print("Ocorreu um erro ao tentar remover")
			else:
				print(valor, "Objeto removido da Lista!")
				print(listObject)
			elif resposta == "4":
				try:
				valor = listObject.RemoverNoFinal()

				except :
			print("Ocorreu um erro ao tentar remover")
			else:
			print(valor, "Objeto removido da lista!")
			print()
			else
			print("Opção Inválida: ", resposta)
		main()
		resposta = input("\n?")
		print("Fim do Programa")