class Fila:
    def __init__(self):
        self.fila = []

    def inserir(self, n):
        self.fila.append(n)

    def excluir(self):
        if not self.vazia():
            del self.fila[0]

    def tamanho(self):
        return len(self.fila)

    def vazia(self):
        return self.tamanho() == 0


# testando a fila...
fila = Fila()
print(fila.vazia())  # inicialmente fila vazia (True)
fila.inserir(1)  # insere elemento 1 na fila
fila.inserir(2)  # insere elemento 2 na fila
fila.inserir(3)  # insere elemento 3 na fila
print(fila.vazia())  # fila NAO vazia (False)
print(fila.tamanho())  # tamanho da fila: 3
fila.excluir()  # remove o elemento 1
fila.excluir()  # remove o elemento 2
fila.excluir()  # remove o elemento 3
print(fila.vazia())  # fila vazia (True)