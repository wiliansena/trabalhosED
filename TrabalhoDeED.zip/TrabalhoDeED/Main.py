from Funcionario import Funcionario
from ListaEstatica import ListaEstatica

class Main:
    continua = False
    dados = ListaEstatica()
    funcionario = Funcionario()
    while continua == False:
        resposta = int(input("-CADASTRO DE FUNCIONARIO- \n\n"
                           "Escolha a opção desejada! \n"
                            "1- inserir: \n"
                            "2-remover: \n"
                            "3-mostrar: \n"
                            "4-buscar:  \n"
                            "5-limpar:  \n"
                            "6-sair\n"
                            "---->\n"))

        if resposta == 1 :
           if dados.qtde == dados.tamanho:
               print("LISTA CHEIA!")
           else:
               funcionario.set_nome(input("Digite o Nome: "))
               funcionario.set_codigo(input("Digite o Código : "))
               funcionario.set_cargo(input("Digite o Cargo: "))
               funcionario.inserir(funcionario.get_nome(), funcionario.get_codigo(), funcionario.get_cargo())


        elif resposta == 2 :
            funcionario.set_codigo(input("Digite o código do funcionário: "))
            dados.remover(funcionario.get_codigo())



        elif resposta == 3 :
            dados.mostrar()


        elif resposta == 4:
            funcionario.set_codigo(input("Digite o código do funcionário: "))
            dados.buscar(funcionario.get_codigo())

        elif resposta == 5:
            dados.limpar()

        elif resposta == 6:
            continua = True







